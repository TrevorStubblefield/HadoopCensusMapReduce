export HADOOP_CONF_DIR=/s/bach/d/under/tstubb/workspace/CS455/hadoop/conf

$HADOOP_HOME/bin/hdfs dfs -rm -r /cs455/analysis-out/

$HADOOP_HOME/bin/hadoop jar dist/analysis.jar cs455.hadoop.Q6.Q6Job /cs455/test /cs455/analysis-out

$HADOOP_HOME/bin/hdfs dfs -cat /cs455/analysis-out/part-r-00000 > output.txt
