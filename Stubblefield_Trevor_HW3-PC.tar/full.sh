JOB=Q7

export HADOOP_CONF_DIR=/s/bach/d/under/tstubb/workspace/CS455/hadoop/client-config

$HADOOP_HOME/bin/hdfs dfs -rm -r /home/census/output

$HADOOP_HOME/bin/hadoop jar dist/analysis.jar cs455.hadoop.${JOB}.${JOB}Job /data/census /home/census/output

$HADOOP_HOME/bin/hdfs dfs -cat /home/census/output/part-r-00000 > answers/${JOB}.txt

